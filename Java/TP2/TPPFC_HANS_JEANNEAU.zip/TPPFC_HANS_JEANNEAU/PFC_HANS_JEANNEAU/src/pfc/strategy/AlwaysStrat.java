package pfc.strategy;
import pfc.Shape;
/**
 * Classe AlwaysStrat permettant, via la m�thode AlwaysStrat(Shape s) � l'ordinateur de jouer
 * toujours la m�me main (Shape s) 
 * @author adrien et Tanguy
 *
 */
public class AlwaysStrat implements Strategy{
	private Shape s;
	
	public AlwaysStrat(Shape s) {
		this.s = s;
	}
	
	public Shape nextShape() {
		return this.s;
	}
	
}
