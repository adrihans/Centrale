package pfc.strategy;
import pfc.Shape;
import util.Input;
/**
 * Classe HumanStrat permettant de choisir � chaque fois la main � jouer.
 * @author adrien et Tanguy
 *
 */

public class HumanStrat implements Strategy {
	
	
	public Shape nextShape() {
		int intLu;
		try {
			System.out.print(" Que voulez vous jouer ? \n");
			System.out.print(" 0 : Pierre \n");
			System.out.print(" 1 : Feuille \n");
			System.out.print(" 2 : Ciseaux \n");
			intLu = Input.readInt();
			System.out.println("lu  => " + Shape.values()[intLu]);
		} catch (java.io.IOException e) {
		    //"exception... : la saisie n'est pas un entier";
		    // on peut par exemple ici fournir une valeur par d�faut : 
		    intLu = 0;
			System.out.println("corrig�  => " + Shape.values()[intLu]);
		}
		return Shape.values()[intLu];
	}
}
