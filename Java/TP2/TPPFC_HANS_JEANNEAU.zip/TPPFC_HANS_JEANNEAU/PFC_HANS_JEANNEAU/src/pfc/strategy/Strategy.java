package pfc.strategy;
import pfc.Shape;
/**
 * Interface Strategy
 * @author adrien et Tanguy
 *
 */
public interface Strategy {
	public Shape nextShape();
}
