package pfc.strategy;
import pfc.Shape;

/**
 * Classe SequenceStrat permettant � l'ordinateur de jouer une s�quence comme strat�gie.
 * Via la m�thode SequenceStrat(Shape[] seq) qui lui permet de jouer la sequence seq.
 * @author adrien et Tanguy
 *
 */
public class SequenceStrat implements Strategy{
	private Shape[] seq;
	private int indice;
	
	public SequenceStrat(Shape[] seq) {
		this.seq = seq;
		this.indice = 0;
	}
	
	public Shape nextShape() {
		Shape s = seq[indice];
		indice  = (indice + 1) % seq.length;
		return s;
	}	
}