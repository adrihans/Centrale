package pfc.strategy;
import pfc.Shape;
import java.util.Random;
/**
 * Classe RandomStrat permettant � l'ordinateur de jouer de fa�on al�atoire.
 * @author adrien et Tanguy
 *
 */
public class RandomStrat implements Strategy{
	public Random rnd;
	
	public RandomStrat() {
		this.rnd = new Random();
	}
	
	public Shape nextShape() {
		int random = rnd.nextInt(Shape.values().length);
		return Shape.values()[random];
	}
	
}
