package pfc;
/**
 * enum Shape d�finissant les trois mains (Pierre, Feuille et Ciseaux) avec la methode 
 * compareShape(Shape s) permettant de d�finir quel est le gagnant pour chaque opposition.
 * @author adrien et Tanguy
 *
 */
public enum Shape {
	PIERRE, FEUILE, CISEAUX;
	
	public int compareShape(Shape s) {
		int d = this.ordinal() - s.ordinal();
		if (d == 0) {
			return 0;
		} else if (d == 1 || d == -2) {
			return 1;
		} else {
			return -1;
		}
	}
}
