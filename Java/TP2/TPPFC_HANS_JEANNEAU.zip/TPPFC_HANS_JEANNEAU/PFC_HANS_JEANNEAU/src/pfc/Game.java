package pfc;
/**
 * Classe Game avec les m�thodes playOneTurn() permettant de jouer un tour et play() qui permet de jouer la partie
 * 
 * @author adrien et Tanguy
 *
 */
public class Game {
	private Player j1;
	private Player j2;
	private int nbround;
	
	
	// Constructeur
	public Game(int nbround, Player j1, Player j2) {
		this.nbround = nbround;
		this.j1 = j1;
		this.j2 = j2;
	}
	/**
	 * M�thode permettant de faire jouer un tour de jeu 
	 */
	public void playOneTurn() {
		
		Player j1= this.j1;
		Player j2=this.j2;
		
		//Chaque joueur joue : 
		Shape s1 = j1.play();
		Shape s2 = j2.play();
		
		// On affiche au joueur ce qu'a jou� l'ordinateur : 
		System.out.println("L'ordinateur a jou� : "+s1);
		
		//On compare les coups des deux joueurs :
		int comp = s1.compareShape(s2);
		if(comp == 1) {
			//Le joueur 1 gagne
			j1.addPoints(2);
			System.out.print(j1.getName()+" gagne la manche !");
		} 
		else if(comp == -1) {
			//Le joueur 2 gagne
			j2.addPoints(2);
			System.out.print(j2.getName()+" gagne la manche !");
		}else {
			//Egalit� 
			j1.addPoints(1);
			j2.addPoints(1);
			System.out.print(" Egalit� dans cette manche !");
		}
	}
	/**
	 * M�thode play() permettant de jouer une partie et de d�signer le vainqueur.
	 */
	// It�re playOneTurn sur nbround
	public void play() {
		int i;
		for (i=0; i<nbround; i +=1) {
			playOneTurn();
		}
		System.out.println("--- END ---");
		System.out.println("Nombre de points de " + j1.getName()+ " : " + j1.getNbPoints());
		System.out.println("Nombre de points de " + j2.getName()+ " : " + j2.getNbPoints());
		if (j1.getNbPoints() > j2.getNbPoints()) {
			System.out.println("GAGNANT: " + j1.getName());	
		} else if (j1.getNbPoints() < j2.getNbPoints()) {
			System.out.println("GAGNANT: " + j2.getName());
		} else {
			System.out.println("EGALITE ! ");
		}
	}
}
