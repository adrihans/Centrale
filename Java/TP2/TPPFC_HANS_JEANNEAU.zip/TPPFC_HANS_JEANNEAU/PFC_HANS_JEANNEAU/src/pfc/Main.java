package pfc;
import pfc.Game;
import pfc.strategy.HumanStrat;
import pfc.strategy.RandomStrat;
import pfc.strategy.SequenceStrat;
import pfc.strategy.Strategy;
import pfc.strategy.AlwaysStrat;
import util.Input;
import java.util.Random;
/**
 * Classe Main pour pouvoir : 
 * - �tablir plusieurs strat�gies (8) 
 * - R�aliser diff�rents affichages
 * - Demander � l'utilisateur d'entrer son nom et le nombre de manches 
 * - Faire appel aux classes pour permettre au joueur de jouer � Pierre Feuille Ciseaux
 * @author adrien et Tanguy
 *
 */

public class Main {
	public static void main(String[] args) {
		// On initialise le nombre de manches en demandant au joueur :
		System.out.print("Combien de manches ? ");
		// On d�clare nbRound, la variable permettant de savoir combien de manches il reste. 
		int nbRound;
		try {
			nbRound = Input.readInt();
		} catch (java.io.IOException e) {
		    //"exception... : la saisie n'est pas un entier";
		    // on fournit 3 manches comme valeur par d�faut : 
		    nbRound = 3;
			System.out.println("corrig�  => " + nbRound);
		}	
		
		
		//Il faut cr�er les deux joueurs :
		//On donne 0 pour initialiser nbPoints
		int nbPointsOrdi=0;
		int nbPointsHuman=0;
		
		// Strategies :  
		// On d�finit les AlwaysStrat pour Pierre, feuille et ciseaux : 
		Shape always1 = Shape.values()[0]; // Pierre
		Shape always2 = Shape.values()[1]; // feuille
		Shape always3 = Shape.values()[2]; // ciseaux
		
		// On d�fini plusieurs s�quences  : 
		// seq1 Pierre puis feuille : 
		Shape[] seq1 = {Shape.values()[0],Shape.values()[1]};
		// seq2  feuille puis ciseaux : 
		Shape[] seq2 = {Shape.values()[1],Shape.values()[2]};
		// seq3 Pierre puis feuille puis ciseaux : 
		Shape[] seq3 = {Shape.values()[0],Shape.values()[1],Shape.values()[2]};
		//seq4 Pierre puis Pierre puis ciseaux : 
		Shape[] seq4 = {Shape.values()[0],Shape.values()[0],Shape.values()[2]};
		
		// On initialise Stratj1 comme �tant al�atoire : 
		Strategy Stratj1 = new RandomStrat();
		
		//On veut que la strat�gie soit al�atoire parmis celles �tablies : 
		Random rnd = new Random();
		int StrategyIndice = rnd.nextInt(8);
		
		// Conditions suivant quelles strat�gie est adopt�e finalement : 
		if(StrategyIndice == 0) {
			Stratj1 = new RandomStrat();
		} else if(StrategyIndice == 1) {
			Stratj1 = new AlwaysStrat(always1);
		} else if(StrategyIndice == 2) {
			Stratj1 = new AlwaysStrat(always2);
		} else if(StrategyIndice == 3) {
			Stratj1 = new AlwaysStrat(always3);
		} else if(StrategyIndice == 4) {
			Stratj1 = new SequenceStrat(seq1);
		} else if(StrategyIndice == 5) {
			Stratj1 = new SequenceStrat(seq2);
		} else if(StrategyIndice == 6) {
			 Stratj1 = new SequenceStrat(seq3);
		} else if(StrategyIndice == 7) {
			Stratj1 = new SequenceStrat(seq4);
		}
		
		System.out.println("Strat�gie num�ro : " + StrategyIndice);
		
		
		//Le joueur humain a forc�ment la strat�gie "HumanStrat"
		Strategy Stratj2 = new HumanStrat();
		
		// Les noms :
		// L'ordinateur a automatiquement le nom "Ordinateur" tandis que l'on demande 
		// au joueur humain de donner son nom. 
		System.out.print(" Quel est votre nom ? ");
		String nameHuman = Input.readString();
		
		
		// Ordinateur : 
		Player j1 = new Player("Ordinateur", Stratj1 ,nbPointsOrdi);
		// Humain : 
		Player j2 = new Player (nameHuman, Stratj2 ,nbPointsHuman);
		
		// On lance le jeu : 
		Game g = new Game(nbRound,j1,j2);
		g.play();			
	}
}