package pfc;

import pfc.strategy.Strategy;
/**
 * Classe Player permettant de d�finir les joueurs. 
 * Chaque joueur � pour attributs : 
 * 		- Son nom name : string
 * 		- Sa strat�gie strat : Strategy
 * 		- son nombre de points nbpoints : int  
 * @author adrien et Tanguy 
 *
 */
public class Player {
	private String name;
	private Strategy strat;
	private int nbpoints;
	
	// Constructeur
	public Player(String name, Strategy s, int nbpoints) {
		this.name = name;
		this.strat = s;
		this.nbpoints = nbpoints;
	}
	
	// Getters et setters
	public Strategy getStrat() {
		return this.strat;
	}
	public void setStrat(Strategy s) {
		this.strat = s;
	}
	public int getNbPoints() {
		return this.nbpoints;
	}
	
	public String getName() {
		return this.name;
	}
	
	
	// Ajouter des points lors de victoires 
	public void addPoints(int i) {
		this.nbpoints += i;
	}
	
	// play
	public Shape play() {
		return this.strat.nextShape();
	}
}
