//the class GrayColor is in the image.color package
package image.color;

/** Class for defining the colors of an image in black and white.
 * @author adrien and Tanguy
 */

public class GrayColor {
	
	/**
	 * Definition of the colors Black and White as constants, 
	 * white being the gray level of 255 and black the gray level of 0:
	 */
	public static final GrayColor WHITE = new GrayColor(255);
	public static final GrayColor BLACK = new GrayColor(0);
	private int level;
	
	/**
	 * Sets the level of gray
	 * @param level : int, the level of gray
	 */
	public GrayColor(int level) {
		this.level = level;
	}
	
	/**
	 * method to get the level of an object
	 * @return the level of the object
	 */
	
	public int getLevel() {
		return this.level;
	}
	
	/**
	 * Method of the equality in the class GrayColor
	 */
	public boolean equals(Object o) {
		
		if (o instanceof GrayColor) {
			// conversion de type
			GrayColor that = (GrayColor)o;

			boolean b1 = (that.WHITE == this.WHITE);
			boolean b2 = (that.BLACK == this.BLACK);
			boolean b3 = (that.getLevel() == this.level);
			boolean b = b3 && b2 && b1;
			
			return b;
			} else {
			return false;
			}
	}

}


