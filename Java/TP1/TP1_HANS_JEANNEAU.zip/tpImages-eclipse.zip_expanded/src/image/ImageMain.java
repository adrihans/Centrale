package image;

import image.Image;
import image.ImageDisplayer;
import java.lang.Integer;

	/**
	 * Class ImageMain with a method main to execute the methods
	 * we defined. 
	 * 
	 * @author adrien and Tanguy
	 */
public class ImageMain {
	
	/**
	 * Method main to show a given image, and the images created with edges and decreasedGrayLevels
	 * from it  
	 * 
	 * @param args: S + n + m
	 * @param : S : str, the path of the image
	 * @param : n : int, the threshold wanted for the edges method
	 * @param : m : int, the number of gray levels wanted for the execution of the function decreasedGrayLevels
	 * 
	 * Example of args : 
	 * 				/images/fruit.pgm 15 16
	 */
	public static void main(String[] args) {
		String filepath = args[0];
		int nbGrayLevels = Integer.parseInt(args[1]);
        int nbEdges = Integer.parseInt(args[2]);
		Image I = Image.initImagePGM(filepath);
		
		image.ImageDisplayer imdis = new ImageDisplayer();
		// imdis.display(imint, title);
		imdis.display(I, "test",100,100);
		
		image.ImageDisplayer imdis2 = new ImageDisplayer();
		Image imedges = I.edges(nbEdges);
		imdis2.display(imedges, "edges",500,100);
		
		image.ImageDisplayer imdis3 = new ImageDisplayer();
		Image imdecrease = I.decreaseNbGrayLevels(nbGrayLevels);
		imdis3.display(imdecrease, "decreased level of gray",1000,100);

	}

}
