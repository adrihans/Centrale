package rental;
/**
 * Class Car extending Vehicle to add another property for the car
 * rented : the number of passengers.
 * @author adrien and Tanguy
 *
 */
public class Car extends Vehicle {
	//Adding the attribute int NbPassengers the number of passengers who can come in the car.	
	int NbPassengers;
	
	//Constructor : 
	public Car(String brand, String model, int productionYear, double dailyRentalPRice, int NbPassengers) {
		super(brand, model, productionYear, dailyRentalPRice);
		this.NbPassengers = NbPassengers;
	}
	//getter of the number of passenger : 
	
	public int getNbPassengers(){
		return this.NbPassengers;
	}
	
	//Method toString() adding the info of the number of passengers : 
	 public String toString() 
	    {
	    	return "Car : Year : " + this.getProductionYear() + ", Brand : " + this.getBrand() + ", Daily Rental Price : " + this.getDailyPrice() + "Number of Passengers : " + this.NbPassengers;
	    }
}
