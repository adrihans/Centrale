package rental;

import java.util.*;

/**
 * Class RentalAgency representing a rental Agency
 * @author adrien and Tanguy
 *
 */
public class RentalAgency {
	//Attribute : 
	private List<Vehicle> listVehicle;
	//Attribute associating the vehicle rented and the client renting it.
	protected Map<Integer,Vehicle> Renting;
	
	// Constructor : 
	public RentalAgency() {
		this.listVehicle =new ArrayList<Vehicle>();
		this.Renting = new HashMap<Integer, Vehicle>();
	}
	//Method addVehicle(Vehicle v) to add a vehicle to the list 
	public void addVehicle(Vehicle v) {
		this.listVehicle.add(v);
	}
	//Method removeVehicle(Vehicle v)to remove a vehicle from the list
	public void removeVehicle(Vehicle v) {
		this.listVehicle.remove(this.listVehicle.indexOf(v));
	}
	/**
	*Method selectVehicles(Criterion c) which return List<Vehicle> listVehicleC
	*the list of vehicles satisfying the criterion. 
	*/
	public List<Vehicle> selectVehicles(Criterion c) {
		List<Vehicle> listVehicleC=new ArrayList<Vehicle>();
		for(Vehicle v : this.listVehicle) {
			//Checking which vehicle satisfies the criterion : 
			if (c.isSatisfiedBy(v)){
				//Adding the vehicle
				listVehicleC.add(v);
			}
		}
		//Returning the list of vehicles satisfying the criterion: 
		return listVehicleC;
	}
	
	/**Method displaySelection(Criterion c) displaying the vehicles of this Agency
	*Satisfying the criterion. 
	*/
	public void displaySelection(Criterion c) {
		for(Vehicle v : this.selectVehicles(c)) {
		System.out.println(v.toString());
		}
	}
	
	/**
	 * Completing the class RentalAgency from the question 7 : 
	 */
	
	
	/**
	 * Method rentVehicle(Client client, Vehicle v) permitting the client to
	 * rent the vehicle
	 * @param client, Client, the client renting the vehicle
	 * @param v, Vehicle, the vehicle rented
	 * @return dailyPrice, double, the the daily price of renting. 
	 */
	public double rentVehicle(Client client, Vehicle v)
				throws UnknownVehicleException, IllegalStateException{	
		this.Renting.put(client.hashCode(),v);
		return v.getDailyPrice();
	}
	
	/**
	 * Method hasRentedAVehicle(Client client) to check if a client 
	 * is currently renting a vehicle. 
	 * @param client
	 * @return boolean, true iff the the client is currently renting a vehicle
	 */
	public boolean hasRentedAVehicle(Client client){
		return this.Renting.containsKey(client.hashCode());
	}
	
	/**
	 * Method isRented(Vehicle v) to check if a vehicle is rented
	 * @param v the Vehicle we want to check if it is currently rented
	 * @return boolean, true iff the Vehicle v is rented
	 */
	public boolean isRented(Vehicle v) {
		return this.Renting.containsValue(v);
	}
	/**
	 * Method returnVehicle(Client client) :
	 * The client returns the vehicle he had rented. 
	 * Nothing happens if he did not rent a vehicle. 
	 * @param client
	 */
	public void returnVehicle(Client client) {
		this.Renting.remove(client.hashCode());
	}
	/**
	 * Method allRentedVehicles to return all the vehicles currently rented. 
	 * @return the rented vehicles, Collection<Vehicle>
	 */
	public Collection<Vehicle> allRentedVehicles(){
		return this.Renting.values();		
	}
	
	
}
