package rental;
import java.util.*;
/**
 * Class InterCriterion permitting to define criterion by intersection of 
 * other criterions. 
 * @author adrien and Tanguy
 *
 */
public class InterCriterion implements Criterion {
	//Attribute : 
	public List<Criterion> listCriterions;
	//Constructor : 
	public InterCriterion(){
		this.listCriterions=new ArrayList<Criterion>();
	}
	public void addCriterion(Criterion c) {
		this.listCriterions.add(c);
	}
	//Checking if the vehicle satisfies the criterion :
	public boolean isSatisfiedBy(Vehicle v) {
		//Boolean variable ret to memorize if the conditions are satisfied
		boolean ret = true;
		for(Criterion c :this.listCriterions) {
			// Checking if all the criterions are satisfied :
			ret = ret && c.isSatisfiedBy(v); 
		}
		return ret;
	}

}
