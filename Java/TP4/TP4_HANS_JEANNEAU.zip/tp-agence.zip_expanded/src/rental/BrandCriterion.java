package rental;

/**
 * Class BrandCriterion of the interface Criterion which permits to check
 * if the brand of the vehicle is the one one wants to rent. 
 * 
 * @author adrien and Tanguy
 *
 */
public class BrandCriterion implements Criterion {
	//Attribute : 
	public String Brand;
	//Constructor : 
	public BrandCriterion(String b) {
		this.Brand=b;
	}
	//Method isSatisfiedBy(Vehicle v) to check if the Vehicle satisfies 
	//the condition of Brand. 
	public boolean isSatisfiedBy(Vehicle v) {
		return v.getBrand().equals(this.Brand);
	}

}
