package rental;

public class UnknownVehicleException extends Exception
{

	private static final long serialVersionUID = 1L;

	public UnknownVehicleException(String msg)
	{
		super(msg);
	}
}
