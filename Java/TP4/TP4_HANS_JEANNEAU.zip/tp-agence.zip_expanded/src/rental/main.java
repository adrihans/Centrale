package rental;

/**
 * Class main Q4 and Q6 to create an Agency, getting a criterion and displaying 
 * the vehicles satisfying the criterion. 
 * @author adrien and Tanguy 
 *
 */
public class main {

    public static void main(String[] args) 
    		throws IllegalStateException, UnknownVehicleException {
		
		//Cerating the agency :
		RentalAgency a = new RentalAgency();
		//Creating three vehicles :
		Vehicle v1 = new Vehicle("Timoleon","jh",2002,90);
		Vehicle v2 = new Vehicle("Timoleon","mer1",2003,120);
		Vehicle v3 = new Vehicle("cit","C3",2005,80);
		
		//Adding the vehicles to the agency: 
		a.addVehicle(v1);
		a.addVehicle(v2);
		a.addVehicle(v3);
		
		/**
		*Question 4 : 
		*System.out.println("Vehicles of the selection :");
		*a.displaySelection(new PriceCriterion(100));
		*/
		
		/**
		*Question 6 :
		*InterCriterion inter =new InterCriterion();
		*inter.addCriterion(new PriceCriterion(100));
		*inter.addCriterion(new BrandCriterion("Timoleon"));
		*System.out.println("Vehicles of the selection :");
		*a.displaySelection(inter);
		*/
		
		/**Question 10 : 
		*Client c1 =new Client("Bob",22);
		

		*RentalAgency B=new SuspiciousRentalAgency();
		*B.addVehicle(v1);
		
		*System.out.println("For a client under 25 : ");
		*System.out.println("Price in the normal agency : " +a.rentVehicle(c1, v1));
		*System.out.println("Price in the suspicious agency : " +B.rentVehicle(c1,v1));
		*/
		
		
		//Question 13 
		Car car1 = new Car("car","car1",1985,200,5);
		Car car2 = new Car("car","car2",1985,25,5);
		Motorbike moto1 = new Motorbike("moto","moto1",2002,85,125);
		a.addVehicle(car1);
		a.addVehicle(car2);
		a.addVehicle(moto1);
		System.out.println("Vehicles of the selection with a price criterion of 100:");
		a.displaySelection(new PriceCriterion(100));
	
	}
	

}
