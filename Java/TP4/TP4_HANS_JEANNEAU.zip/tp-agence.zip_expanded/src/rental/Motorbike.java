package rental;
/**
 * Class Motorbike extending Vehicle to add another property for the motorbike
 * rented.
 * @author adrien and Tanguy
 *
 */
public class Motorbike extends Vehicle {
	//Attribute : 
	int Cyl;
	//Constructor : 
	public Motorbike(String brand, String model, int productionYear, double dailyRentalPRice, int cyl) {
		super(brand, model, productionYear, dailyRentalPRice);
		this.Cyl = cyl;
	}

	//getter : 
	
	public int getCyl(){
		return this.Cyl;
	}
	
	//Method toString() adding the info of the cyl : 
	 public String toString() 
	    {
	    	return "Motorbike : Year : " + this.getProductionYear() + ", Brand : " + this.getBrand() + ", Daily Rental Price : " + this.getDailyPrice() + ", Cyl : " + this.Cyl + "cm3";
	    }
}