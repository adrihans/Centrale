package rental;
/**
 * Class PriceCriterion of the interface Criterion to check if the price of 
 * the vehicle satisfies the criterion
 * 
 * @author adrien and Tanguy
 *
 */
public class PriceCriterion implements Criterion {
	//Attribute : 
	public int price;
	//Constructor : 
	public PriceCriterion(int p) {
		this.price=p;
	}
	//Method isSatisfiedBy(Vehicle v) which returns true 
	public boolean isSatisfiedBy(Vehicle v) {
		return v.getDailyPrice()<this.price;
	}

}
