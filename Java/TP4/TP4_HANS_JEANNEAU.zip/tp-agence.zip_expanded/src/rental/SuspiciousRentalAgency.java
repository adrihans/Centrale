package rental;
/**
 * Class SuspiciousRentalAgency applying a 10% cost on the daily renting 
 * price if the client is under 25.
 * To do so, we modify the method rentVehicle(Client client, Vehicle v)
 * We use "super"
 * @author adrien and Tanguy
 *
 */
public class SuspiciousRentalAgency extends RentalAgency{
	
	public double rentVehicle(Client client, Vehicle v)
			throws UnknownVehicleException, IllegalStateException{	
		
	this.Renting.put(client.hashCode(),v);
	//If the age of the client is under 25, the price is 10% higher
	if (client.getAge()<25) {
		return super.rentVehicle(client, v)*1.1;
	}
	else {
	return super.rentVehicle(client, v);
	}
	}
	
}
